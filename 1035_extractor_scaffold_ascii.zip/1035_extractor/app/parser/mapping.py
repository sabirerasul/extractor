import pandas as pd
from rapidfuzz import fuzz
from typing import Dict, Any, Tuple, List

SYNONYMS = {
    "year": ["Policy Year","Year","Yr"],
    "age": ["Age","Insured Age"],
    "premium": ["Planned Premium","Scheduled Premium","Annual Outlay","Modal Premium","Premium Outlay"],
    "death_benefit": ["Death Benefit","Face Amount","Specified Amount"],
    "cash_value": ["Account Value","Accumulation Value","Cash Value","Policy Value"],
    "surrender_charge": ["Surrender Charge","Surr Chg","Surrender Fee","Surrender Penalty"],
    "net_surrender_value": ["Net Cash Surrender Value","Net Surrender Value","Net CSV","Net SV"],
    "loan_balance": ["Policy Indebtedness","Outstanding Loan","Policy Loan","Loan Balance","Policy Debt"],
    "loan_interest": ["Accrued Loan Interest","Loan Interest"],
    "withdrawals": ["Withdrawal","Loan/Withdrawal","Distribution"]
}

def clean_number(x: str):
    if x is None: return None
    s = str(x).strip()
    if s == "": return None
    s = s.replace(",", "")
    # parentheses negative
    if s.startswith("(") and s.endswith(")"):
        s = "-" + s[1:-1]
    try:
        return float(s)
    except Exception:
        return None

def label_columns(df: pd.DataFrame) -> Dict[str, int]:
    # Try header match first
    header_map: Dict[str, int] = {}
    headers = [str(h).strip() for h in list(df.iloc[0, :])]
    for canon, syns in SYNONYMS.items():
        best = (-1, -1)
        for idx, h in enumerate(headers):
            for s in syns + [canon]:
                score = fuzz.partial_ratio(s.lower(), h.lower())
                if score > best[0]:
                    best = (score, idx)
        if best[0] >= 70:
            header_map[canon] = best[1]
    return header_map

def shape_score(df: pd.DataFrame, col_idx: int) -> float:
    # Basic monotonic patterns, returns 0..1
    try:
        vals = [clean_number(v) for v in df.iloc[1:, col_idx].to_list()]
        vals = [v for v in vals if v is not None]
        if len(vals) < 3:
            return 0.0
        # A simple heuristic: many money cols mostly non-negative
        nonneg = sum(1 for v in vals if v >= 0) / float(len(vals))
        return nonneg
    except Exception:
        return 0.0

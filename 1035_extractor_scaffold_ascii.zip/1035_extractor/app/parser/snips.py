import fitz, base64

def crop_to_b64(pdf_path: str, page_index: int, rect: fitz.Rect) -> str:
    with fitz.open(pdf_path) as doc:
        page = doc[page_index]
        pix = page.get_pixmap(clip=rect, dpi=200)
        return base64.b64encode(pix.tobytes("png")).decode("ascii")

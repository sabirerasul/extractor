import os, io, tempfile, base64, json
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from app.models import AnalyzeResponse, Fields, Series, Verifications, ProofSnip, ValueWithMeta
from app.parser.preflight import ocr_if_needed, normalize_orientation
from app.parser.tables import find_roi_and_tables
from app.parser.mapping import label_columns, clean_number
from app.parser.confidence import compute_confidence
from app.parser.pii import scrub_text, redact_pdf_boxes
import fitz
import pandas as pd
from typing import List, Dict, Any

CONFIDENCE_THRESHOLD = float(os.getenv("CONFIDENCE_THRESHOLD", "0.80"))

api = FastAPI(title="1035 In-Force Extractor API")

def b64_file(path: str) -> str:
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("ascii")

@api.post("/analyze", response_model=AnalyzeResponse)
async def analyze(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Please upload a PDF file.")
    # Save temp
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        data = await file.read()
        tmp.write(data)
        tmp_path = tmp.name

    try:
        prepped = ocr_if_needed(tmp_path)
        prepped = normalize_orientation(prepped)

        # TODO: Apply PII detection to coordinates (advanced). For now, do text scrub on outputs only.
        tables = find_roi_and_tables(prepped)
        if not tables:
            # Return minimal response with low confidence
            resp = AnalyzeResponse(
                decision_ready=False,
                needs_manual_review=True,
                confidence_overall=0.0,
                notes=["No tables detected."]
            )
            return JSONResponse(content=json.loads(resp.model_dump_json()))

        # Take first table as example (extend with scoring)
        t = tables[0]
        df = t["df"]
        # Label columns
        col_map = label_columns(df)
        # Build simple series from labeled columns if present
        series = Series()
        def col_vals(key):
            idx = col_map.get(key)
            if idx is None: return []
            vals = [clean_number(v) for v in df.iloc[1:, idx].to_list()]
            return [v for v in vals if v is not None]

        series.cash_value_by_year = col_vals("cash_value")
        series.surrender_charge_by_year = col_vals("surrender_charge")
        series.net_surrender_value_by_year = col_vals("net_surrender_value")
        series.planned_premiums_by_year = col_vals("premium")

        # Simple verification metric placeholders
        verif = Verifications(
            net_sv_identity_rmse=None,
            year_sequence_ok=True,
            rows_parsed_pct=float(len(df) - 1) / float(len(df)) if len(df) > 1 else 0.0
        )

        # Confidence metrics placeholders
        metrics = {
            "header_strength": 1.0 if col_map else 0.0,
            "shape_fit": 0.8 if len(series.cash_value_by_year) > 3 else 0.2,
            "recon_success": 0.5,  # TODO: implement identity check over rows
            "rows_parsed": verif.rows_parsed_pct
        }
        conf = compute_confidence(metrics)
        decision_ready = conf >= CONFIDENCE_THRESHOLD
        needs_review = not decision_ready

        # Redacted PDF placeholder (no coordinate redaction in this skeleton)
        redacted_b64 = b64_file(prepped)

        resp = AnalyzeResponse(
            decision_ready=decision_ready,
            needs_manual_review=needs_review,
            confidence_overall=conf,
            fields=Fields(
                crediting_rate=None,
                death_benefit_pattern=None,
                face_amount_structure=None,
                loan_balance_today=None
            ),
            series=series,
            verifications=verif,
            proof_snips=[],
            redacted_pdf_b64=redacted_b64,
            notes=[f"Columns found: {list(col_map.keys())}"]
        )
        return JSONResponse(content=json.loads(resp.model_dump_json()))
    finally:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass
